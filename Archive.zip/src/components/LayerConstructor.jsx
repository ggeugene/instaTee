let nextLayerId = 0
let zIndex = 1
export function LayerConstructor({ ...options }, type) {
  let layer = {
    id: nextLayerId++,
    focused: false,
    type: type,
    zIndex: zIndex++,
    coords: {
      x: 0,
      y: 0,
    },
    dimensions: {
      width: options.dimensions.width + 'px',
      height: options.dimensions.height + 'px',
    },
    rotateAngle: 0,
  }
  if (type === 'image') {
    layer.content = options.imageUrl
    layer.props = {
      brightness: 0,
      contrast: 0,
      hue: 0,
    }
  }

  return layer

  // return {
  //   id: nextLayerId++,
  //   focused: false,
  //   coords: {
  //     x: 0,
  //     y: 0,
  //   },
  //   type: type,
  //   dimensions: {
  //     width: options.dimensions.width + 'px',
  //     height: options.dimensions.height + 'px',
  //   },
  //   rotateAngle: 0,
  //   content: options.imageUrl,
  //   props: {
  //     brightness: 0,
  //     contrast: 0,
  //     hue: 0,
  //   },
  // }
}
