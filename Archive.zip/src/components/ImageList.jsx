import React, { Component } from 'react'
import LayerImage from './LayerImage'
import { connect } from 'react-redux'

// const ImageList = images => {
//   console.log(images.images)
//   return images.images.map(image => (
//     <div
//       className='single-layer__container'
//       style={{
//         width: image.dimensions.width,
//         height: image.dimensions.height,
//       }}>
//       <LayerImage key={image.id} {...image} />
//     </div>
//   ))
// }

class ImageList extends Component {
  render() {
    return this.props.images.map(image => (
      <div
        key={image.id}
        className='single-layer__container'
        style={{
          width: image.dimensions.width,
          height: image.dimensions.height,
        }}>
        <LayerImage {...image} />
      </div>
    ))
  }
}

const mapStateToProps = state => {
  console.log(state.layers)
  return {
    images: state.layers,
  }
}

export default connect(mapStateToProps)(ImageList)
