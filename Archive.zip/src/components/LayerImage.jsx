import React from 'react'

const LayerImage = ({ content, dimensions }) => {
  const styles = dimensions
  return <img src={content} style={styles} alt='' />
}

export default LayerImage
